UFRGS TeX Users Group
=====================

Estes arquivos compoem o pacote de estilos LaTeX de documentos para o INF/UFRGS. 

Várias classes de documentos são disponibilizadas, como por exemplo:

  * **iiufrgs.cls**, para documentos do tipo TI, dissertacao, tese, etc.
  * **sa.cls**, para produzir artigos para o Seminário de Andamento
  * **iiletter**, para produzir cartas com logotípos do II, em duas versões

Cada uma tem um arquivo de exemplo, no diretório "exemplos".

### Participação

Comentários e sugestões são **MUITO** bem-vindos. Envie-os para a lista de discussões do grupo de usuários TeX da UFRGS:

  * utug-l@inf.ufrgs.br

Para cadastrar-se na lista, visite

  * https://listas.inf.ufrgs.br/mailman/listinfo/utug-l

ou envie e-mail para utug-l-request@inf.ufrgs.br com a palavra _subscribe_ no corpo da mensagem.

### Instalação

Os arquivos necessários para compilar os fontes tex encontram-se no diretório *inputs/* . Copie todos os arquivos para o diretório do seu documento ou utilize o Makefile para outras opções.

Os links abaixo podem ser úteis para a instalação do pacote:

  * http://www.tex.ac.uk/cgi-bin/texfaq2html?label=privinst
  * http://www.tex.ac.uk/cgi-bin/texfaq2html?label=what-TDS
